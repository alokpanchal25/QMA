  import { Component, OnInit, ViewChild } from '@angular/core';
  import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import { ChangeEvent } from '@ckeditor/ckeditor5-angular/ckeditor.component';
  
  @Component({
    selector: 'app-cm-editor',
    templateUrl: './cm-editor.component.html',
    styleUrls: ['./cm-editor.component.css']
  })
  export class CmEditorComponent  {
    public Editor = ClassicEditor;
    config:any;
    constructor() {
      this.config = {
        
          toolbar: [  'bold', 'italic', '|', 'undo', 'redo', '|', 'link', 'heading', 'imageUpload' ,
          /* 'imageStyle:full',
          'imageStyle:side',
          '|',
          'imageTextAlternative' , */
          '|',
        'insertTable']};
    }
      
    public onChange( { editor }: ChangeEvent ) {
      const data = editor.getData();

      console.log( data );
     
      
  }
    sendMail({editor}):void {
      console.log(editor.getData());
      this.saveArticle()
    }

    @ViewChild('myEditor') myEditor: any;

    saveArticle() {
      console.log(this.getArticleContent());
      console.log(ClassicEditor.builtinPlugins.map( plugin => plugin.pluginName ));
    }

    private getArticleContent() {
      if (this.myEditor && this.myEditor.editorInstance) {
        return this.myEditor.editorInstance.getData();
      }

      return '';
    }
    onEditorChange($event: any): void {
      alert("");
      
  }

  }
