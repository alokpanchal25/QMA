import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { jqxEditorModule }    from 'jqwidgets-ng/jqxeditor';
import { EditorModule } from '@tinymce/tinymce-angular';

import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { CmEditorComponent } from './cm-editor/cm-editor.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { TinyEditorComponent } from './tiny-editor/tiny-editor.component';


@NgModule({
  declarations: [
    AppComponent,
    CmEditorComponent,
    TinyEditorComponent
  ],
  imports: [
    BrowserModule,  CommonModule, jqxEditorModule, CKEditorModule, EditorModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
