import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { jqxEditorModule }    from 'jqwidgets-ng/jqxeditor';

import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';
import { CmEditorComponent } from './cm-editor/cm-editor.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';


@NgModule({
  declarations: [
    AppComponent,
    CmEditorComponent
  ],
  imports: [
    BrowserModule,  CommonModule, jqxEditorModule, CKEditorModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
