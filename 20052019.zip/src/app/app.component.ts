import { Component, ViewChild, AfterViewInit } from '@angular/core';
//import { jqxEditorComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxeditor';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements AfterViewInit
{   content : string = "hi this is the test content <br/> regards, <br/> -Alok";

  //  @ViewChild('editorReference') myEditor: jqxEditorComponent;
 
    ngAfterViewInit(): void
    {
    //    this.myEditor.createComponent({ });
    }   

  getWidth() : any {
		// if (document.body.offsetWidth < 850) {
		// 	return '90%';
		// }
		// return 850;
  }
  
  sendMail(){
    //console.log(this.myEditor.val());
  }
  getContent(){
   // this.myEditor.val(this.content);
  }
   
//Get Properties
//let height = this.myEditor.height();
 
//Set Properties
//this.myEditor.height(350);
//this.myEditor.setOptions({ lineBreak: "div", width: 450, height: 300 });

}
