import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tiny-editor',
  templateUrl: './tiny-editor.component.html',
  styleUrls: ['./tiny-editor.component.css']
})
export class TinyEditorComponent implements OnInit {
value = "this is <b>intial</b> value";
config = {
  selector: '#TD',
  menubar: false,
  plugins : 'template formatpainter tinymcespellchecker save advlist autolink link image imagetools powerpaste lists charmap print preview table code ',
  toolbar: 'formatpainter tinymcespellchecker template fontselect fontsizeselect undo redo lists charmap | styleselect | bold italic | link image | '+ 
          'print table code numlist bullist outdent indent  editimage imageoptions save',
          paste_preprocess: function(plugin, args) {
          //  var urlCreator = window.URL ;
           // var imageUrl = urlCreator.createObjectURL(args.content.src);
           // console.log(args.content);
           // args.content = ' preprocess';
          },
        //  browser_spellcheck: true,
     //contextmenu: false,
        spellchecker_language: 'en',
  images_dataimg_filter: function(img) {
            console.log(img);//.hasAttribute('internal-blob');
          },
templates: [
    { title: 'Some title 1', description: 'Some desc 1', content: 'My content' },
    { title: 'Some title 2', description: 'Some desc 2', content: '<div class="mceTmpl"><span class="cdate">cdate</span><span class="mdate">mdate</span>My content2</div>' }
  ],

};

  constructor() { }

  ngOnInit() {

  }

  saveContent(eObj:any){
    console.log(eObj.event.content)
  }
}
